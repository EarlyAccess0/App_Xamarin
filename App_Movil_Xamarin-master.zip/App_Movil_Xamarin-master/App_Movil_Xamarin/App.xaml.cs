﻿using App_Movil_Xamarin.Services;
using ListaTareasApp.Services;
using ListaTareasApp;
using System;
using System.IO;
using Xamarin.Forms;
using App_Movil_Xamarin.Views;

namespace App_Movil_Xamarin
{
    public partial class App : Application
    {
      
        public static TareasDatabase TareasDB { get; private set; }

        public App()
        {
            InitializeComponent();

            
            string dbPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "tareas.db3");

            TareasDB = new TareasDatabase(dbPath);

           
            MainPage = new NavigationPage(new MainPage());
        }

        protected override void OnStart() { }

        protected override void OnSleep() { }

        protected override void OnResume() { }
    }
}

