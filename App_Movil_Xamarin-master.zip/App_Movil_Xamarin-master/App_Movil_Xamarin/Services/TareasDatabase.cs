﻿using SQLite;
using ListaTareasApp.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ListaTareasApp.Services
{
    public class TareasDatabase
    {
        readonly SQLiteAsyncConnection _database;

        public TareasDatabase(string dbPath)
        {
            _database = new SQLiteAsyncConnection(dbPath);
            _database.CreateTableAsync<Tarea>().Wait();
        }

        public Task<List<Tarea>> ObtenerTareasAsync() => _database.Table<Tarea>().ToListAsync();
        public Task<Tarea> ObtenerTareaAsync(int id) => _database.Table<Tarea>().Where(i => i.Id == id).FirstOrDefaultAsync();
        public Task<int> GuardarTareaAsync(Tarea tarea) => tarea.Id != 0 ? _database.UpdateAsync(tarea) : _database.InsertAsync(tarea);
        public Task<int> EliminarTareaAsync(Tarea tarea) => _database.DeleteAsync(tarea);
    }
}
