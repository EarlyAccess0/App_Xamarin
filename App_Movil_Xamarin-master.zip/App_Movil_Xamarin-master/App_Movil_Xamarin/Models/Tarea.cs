﻿using SQLite;

namespace ListaTareasApp.Models
{
    public class Tarea
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }

        public string Nombre { get; set; }
        public string Descripcion { get; set; }
    }
}
