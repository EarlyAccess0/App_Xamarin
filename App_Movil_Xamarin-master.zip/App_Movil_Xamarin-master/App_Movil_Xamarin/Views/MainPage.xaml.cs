﻿using App_Movil_Xamarin;
using ListaTareasApp.Models;
using System;
using Xamarin.Forms;
using App_Movil_Xamarin.Views;
using App_Movil_Xamarin.Services;



namespace App_Movil_Xamarin.Views
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();
            listaTareas.ItemsSource = await App.TareasDB.ObtenerTareasAsync();
        }

        private async void AgregarTarea_Clicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new TareaPage());
        }

        private async void ListaTareas_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            if (e.Item != null)
            {
                var tareaSeleccionada = (Tarea)e.Item;
                await Navigation.PushAsync(new TareaPage(tareaSeleccionada));
            }
        }
    }
}
