﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using App_Movil_Xamarin.Models;
using App_Movil_Xamarin;
using ListaTareasApp.Models;

namespace App_Movil_Xamarin.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TareaPage : ContentPage
    {
        private Tarea tarea;

        public TareaPage(Tarea tarea = null)
        {
            InitializeComponent();
            this.tarea = tarea;

            if (tarea != null)
            {
                NombreEntry.Text = tarea.Nombre;
                DescripcionEditor.Text = tarea.Descripcion;
            }
        }

        private async void OnGuardarClicked(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NombreEntry.Text))
            {
                await DisplayAlert("Error", "El nombre es obligatorio", "OK");
                return;
            }

            var nuevaTarea = new Tarea
            {
                Id = tarea?.Id ?? 0,
                Nombre = NombreEntry.Text,
                Descripcion = DescripcionEditor.Text
            };

            await App.TareasDB.GuardarTareaAsync(nuevaTarea);
            await Navigation.PopAsync();
        }
    }
}
