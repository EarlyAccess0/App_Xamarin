﻿using App_Movil_Xamarin.ViewModels;
using System.ComponentModel;
using Xamarin.Forms;

namespace App_Movil_Xamarin.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        public ItemDetailPage()
        {
            InitializeComponent();
            BindingContext = new ItemDetailViewModel();
        }
    }
}